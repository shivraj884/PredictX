CREATE DATABASE IF NOT EXISTS predictx CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE predictx;

CREATE TABLE IF NOT EXISTS telemetry (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  received_at TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  device_id VARCHAR(80) NOT NULL DEFAULT 'esp32',
  temperature_c DOUBLE NULL,
  humidity_pct DOUBLE NULL,
  vibration_x DOUBLE NULL COMMENT 'MPU6050 X-axis acceleration RMS in g (or calibrated unit)',
  vibration_y DOUBLE NULL COMMENT 'MPU6050 Y-axis acceleration RMS in g (or calibrated unit)',
  vibration_z DOUBLE NULL COMMENT 'MPU6050 Z-axis acceleration RMS in g (or calibrated unit)',
  audio_value DOUBLE NULL COMMENT 'INMP441 sound sample RMS, arbitrary PCM units unless calibrated',
  acs712_reading DOUBLE NULL COMMENT 'ACS712 analog/current sensor reading; units depend on firmware calibration',
  gyro_x DOUBLE NULL, gyro_y DOUBLE NULL, gyro_z DOUBLE NULL,
  vibration_magnitude DOUBLE NULL,
  motor_rpm DOUBLE NULL,
  motor_load DOUBLE NULL,
  raw_json JSON NOT NULL,
  INDEX idx_telemetry_received_at (received_at),
  INDEX idx_telemetry_device_time (device_id, received_at)
);

CREATE TABLE IF NOT EXISTS model_predictions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  telemetry_id BIGINT UNSIGNED NOT NULL,
  predicted_at TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  anomaly_flag TINYINT(1) NOT NULL,
  anomaly_score DOUBLE NULL,
  anomaly_probability DOUBLE NULL,
  failure_prediction TINYINT(1) NULL,
  failure_probability DOUBLE NULL,
  model_version VARCHAR(80) NULL,
  CONSTRAINT fk_prediction_telemetry FOREIGN KEY (telemetry_id) REFERENCES telemetry(id) ON DELETE CASCADE,
  INDEX idx_prediction_time (predicted_at)
);
