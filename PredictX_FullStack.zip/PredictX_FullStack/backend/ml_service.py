from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

BASE = Path(__file__).resolve().parent
DATASET = BASE / 'data' / 'preprocessed_sensor_data.csv'
MODEL_DIR = BASE / 'models'
MODEL_DIR.mkdir(exist_ok=True)
ANOMALY_PATH = MODEL_DIR / 'anomaly_model.joblib'
CLASSIFIER_PATH = MODEL_DIR / 'anomaly_classifier.joblib'

FEATURES = [
    'mpu6050_accel_x', 'mpu6050_accel_y', 'mpu6050_accel_z',
    'mpu6050_gyro_x', 'mpu6050_gyro_y', 'mpu6050_gyro_z',
    'soundsensor_reading', 'acs712_reading', 'dht22_temperature',
    'dht22_humidity', 'mpu6050_vibration_magnitude'
]
TARGET = 'is_anomaly'

ALIASES = {
    'mpu6050_accel_x': ('mpu6050_accel_x', 'accel_x_rms', 'accel_x', 'vibration_x'),
    'mpu6050_accel_y': ('mpu6050_accel_y', 'accel_y_rms', 'accel_y', 'vibration_y'),
    'mpu6050_accel_z': ('mpu6050_accel_z', 'accel_z_rms', 'accel_z', 'vibration_z'),
    'mpu6050_gyro_x': ('mpu6050_gyro_x', 'gyro_x'),
    'mpu6050_gyro_y': ('mpu6050_gyro_y', 'gyro_y'),
    'mpu6050_gyro_z': ('mpu6050_gyro_z', 'gyro_z'),
    'soundsensor_reading': ('soundsensor_reading', 'sound_rms', 'audio_rms', 'audio_value', 'audio', 'sound'),
    'acs712_reading': ('acs712_reading', 'acs712', 'current_reading', 'current_sensor', 'current', 'current_amps'),
    'dht22_temperature': ('dht22_temperature', 'temperature_c', 'temp', 'temperature'),
    'dht22_humidity': ('dht22_humidity', 'humidity_pct', 'humidity'),
    'mpu6050_vibration_magnitude': ('mpu6050_vibration_magnitude', 'vibration_magnitude'),
}

def _dataset():
    if not DATASET.exists():
        raise FileNotFoundError(f'Dataset not found: {DATASET}. Put preprocessed_sensor_data.csv in backend/data/.')
    df = pd.read_csv(DATASET)
    missing = [c for c in FEATURES + [TARGET] if c not in df.columns]
    if missing:
        raise ValueError(f'Dataset is missing required columns: {missing}')
    for col in FEATURES + [TARGET]:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    df = df.replace([np.inf, -np.inf], np.nan).dropna(subset=[TARGET])
    # Training records are axis samples in g; use magnitudes for comparison with RMS telemetry.
    for axis in ('mpu6050_accel_x', 'mpu6050_accel_y', 'mpu6050_accel_z'):
        df[axis] = df[axis].abs()
    df[TARGET] = df[TARGET].astype(int)
    df = df[df[TARGET].isin([0, 1])].copy()
    if df[TARGET].nunique() < 2:
        raise ValueError('is_anomaly must contain both 0 (normal) and 1 (anomaly) labels.')
    return df

def _payload_row(payload, columns=FEATURES):
    result = {}
    for feature in columns:
        value = None
        used_key = None
        for key in ALIASES.get(feature, (feature,)):
            if payload.get(key) is not None:
                used_key = key
                try:
                    value = float(payload[key])
                except (TypeError, ValueError):
                    value = np.nan
                break
        # The previous ESP32 sketch publishes accel_*_rms in m/s^2; dataset axes are in g.
        if feature.startswith('mpu6050_accel_') and used_key in ('accel_x_rms', 'accel_y_rms', 'accel_z_rms') and pd.notna(value):
            value = abs(value) / 9.80665
        elif feature.startswith('mpu6050_accel_') and pd.notna(value):
            value = abs(value)
        result[feature] = value if value is not None else np.nan
    # Derive magnitude from the three axes if the firmware doesn't send it separately.
    if pd.isna(result.get('mpu6050_vibration_magnitude', np.nan)):
        xyz = [result.get('mpu6050_accel_x'), result.get('mpu6050_accel_y'), result.get('mpu6050_accel_z')]
        if all(pd.notna(v) for v in xyz):
            result['mpu6050_vibration_magnitude'] = float(np.sqrt(sum(v*v for v in xyz)))
    return pd.DataFrame([result], columns=columns)

def train_models():
    df = _dataset()
    X, y = df[FEATURES], df[TARGET]
    anomaly_pipeline = Pipeline([
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler()),
        ('model', IsolationForest(n_estimators=200, contamination=max(0.01, min(0.20, float(y.mean()))), random_state=42))
    ])
    anomaly_pipeline.fit(X)
    joblib.dump({'pipeline': anomaly_pipeline, 'features': FEATURES, 'version': 'predictx-iforest-sensor-v2', 'dataset': DATASET.name}, ANOMALY_PATH)

    # Keep a held-out report for transparency; final model is then fit on all labeled rows.
    stratify = y if y.value_counts().min() >= 2 else None
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=stratify)
    classifier = Pipeline([
        ('imputer', SimpleImputer(strategy='median')),
        ('model', RandomForestClassifier(n_estimators=300, class_weight='balanced', random_state=42, min_samples_leaf=2, n_jobs=-1))
    ])
    classifier.fit(X_train, y_train)
    pred = classifier.predict(X_test)
    metrics = {
        'test_rows': int(len(y_test)),
        'accuracy': round(float(accuracy_score(y_test, pred)), 4),
        'precision': round(float(precision_score(y_test, pred, zero_division=0)), 4),
        'recall': round(float(recall_score(y_test, pred, zero_division=0)), 4),
        'f1': round(float(f1_score(y_test, pred, zero_division=0)), 4),
    }
    classifier.fit(X, y)
    joblib.dump({'pipeline': classifier, 'features': FEATURES, 'version': 'predictx-rf-anomaly-v2', 'dataset': DATASET.name, 'metrics': metrics}, CLASSIFIER_PATH)
    return {
        'anomaly_model': 'trained', 'classifier_model': 'trained', 'failure_model': 'not applicable (dataset target is is_anomaly)',
        'rows': int(len(df)), 'features': FEATURES, 'target': TARGET,
        'class_counts': {str(int(k)): int(v) for k, v in y.value_counts().sort_index().items()},
        'metrics': metrics, 'dataset_kind': 'Preprocessed sensor anomaly dataset',
        'note': 'Metrics are from a hold-out split of this dataset; with only a small dataset, validate on separate real machine runs before relying on predictions.'
    }

def model_status():
    try:
        df = _dataset()
        rows = len(df)
        counts = {str(int(k)): int(v) for k, v in df[TARGET].value_counts().sort_index().items()}
        kind = 'Preprocessed sensor anomaly dataset'
    except Exception as exc:
        rows, counts, kind = 0, {}, f'dataset error: {exc}'
    clf = joblib.load(CLASSIFIER_PATH) if CLASSIFIER_PATH.exists() else {}
    return {
        'anomaly_ready': ANOMALY_PATH.exists(), 'failure_ready': CLASSIFIER_PATH.exists(),
        'classifier_ready': CLASSIFIER_PATH.exists(), 'dataset': DATASET.name,
        'dataset_kind': kind, 'dataset_rows': rows, 'class_counts': counts,
        'features': FEATURES, 'target': TARGET, 'metrics': clf.get('metrics'), 'dataset_path': str(DATASET)
    }

def predict(payload):
    result = {'anomaly_flag': None, 'anomaly_score': None, 'anomaly_probability': None,
              'failure_prediction': None, 'failure_probability': None, 'model_version': None,
              'prediction_note': None}
    if not ANOMALY_PATH.exists() or not CLASSIFIER_PATH.exists():
        train_models()
    row = _payload_row(payload)
    provided = [c for c in FEATURES if pd.notna(row.iloc[0][c])]
    # Need the core new sensor readings; avoid silently predicting from a row with no sensor input.
    core = ['mpu6050_accel_x', 'mpu6050_accel_y', 'mpu6050_accel_z', 'soundsensor_reading', 'acs712_reading']
    missing_core = [c for c in core if pd.isna(row.iloc[0][c])]
    if missing_core:
        result['model_version'] = 'predictx-sensor-v2'
        result['prediction_note'] = 'Prediction skipped; missing live sensor fields: ' + ', '.join(missing_core)
        return result
    am = joblib.load(ANOMALY_PATH)
    score = float(am['pipeline'].decision_function(row[am['features']])[0])
    iflag = int(am['pipeline'].predict(row[am['features']])[0] == -1)
    cm = joblib.load(CLASSIFIER_PATH)
    c_row = row[cm['features']]
    probs = cm['pipeline'].predict_proba(c_row)[0]
    classes = list(cm['pipeline'].named_steps['model'].classes_)
    anomaly_prob = float(probs[classes.index(1)]) if 1 in classes else float(iflag)
    cflag = int(cm['pipeline'].predict(c_row)[0])
    result.update(anomaly_flag=cflag, anomaly_score=score, anomaly_probability=anomaly_prob,
                  model_version=am['version'] + '+' + cm['version'])
    missing_optional = [c for c in FEATURES if c not in provided and c not in ('mpu6050_vibration_magnitude',)]
    if missing_optional:
        result['prediction_note'] = 'Some optional model inputs were missing and median-imputed: ' + ', '.join(missing_optional)
    return result
