USE predictx;
-- Existing schema already stores all three axes and audio in these columns.
-- This migration is safe to run only if the columns do not already exist; on the starter schema they do exist.
-- No ALTER is required: new MQTT keys are mapped to vibration_x/y/z and audio_value by db.py.
SELECT 'RMS fields map to telemetry.vibration_x, vibration_y, vibration_z and audio_value' AS migration_note;
