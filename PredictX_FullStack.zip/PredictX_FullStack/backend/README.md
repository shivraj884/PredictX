# PredictX Backend

FastAPI + MySQL + MQTT + scikit-learn anomaly models.

## Dataset

`data/preprocessed_sensor_data.csv` is the active training dataset. It must contain numeric columns `mpu6050_accel_x`, `mpu6050_accel_y`, `mpu6050_accel_z`, `mpu6050_gyro_x`, `mpu6050_gyro_y`, `mpu6050_gyro_z`, `soundsensor_reading`, `acs712_reading`, `dht22_temperature`, `dht22_humidity`, `mpu6050_vibration_magnitude`, and target `is_anomaly` with both 0 and 1 classes.

`POST /api/models/train` trains an Isolation Forest and a Random Forest anomaly classifier, returning hold-out evaluation metrics. Do not interpret those metrics as real-world performance without separate validation data.

## API

- `GET /api/health`
- `GET /api/telemetry?limit=120`
- `GET /api/predictions?limit=120`
- `GET /api/models/status`
- `POST /api/models/train`
- `GET /api/dataset`
- `GET /api/collection`
- `POST /api/collection/start` and `/api/collection/stop`

The database startup routine adds columns to an existing telemetry table for ACS712, gyro axes and vibration magnitude, plus anomaly probability in model_predictions.
