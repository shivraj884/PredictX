
import json
import os
import threading
import time
from datetime import datetime, timezone

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from db import (
    init_db,
    insert_telemetry,
    fetch_telemetry,
    count_telemetry,
    save_prediction,
    fetch_predictions,
)
from ml_service import predict, train_models, model_status

load_dotenv()

# --------------------------------------------------
# FastAPI application
# --------------------------------------------------

app = FastAPI(
    title="PredictX REST API",
    version="1.0.0",
    description=(
        "ESP32 MQTT telemetry, MySQL persistence "
        "and ML maintenance analytics"
    ),
)

# --------------------------------------------------
# CORS CONFIGURATION
# Allow React development server on both hostnames.
# CORS_ORIGINS in .env can add additional origins.
# --------------------------------------------------

default_origins = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
]

configured_origins = [
    origin.strip().rstrip("/")
    for origin in os.getenv("CORS_ORIGINS", "").split(",")
    if origin.strip()
]

origins = list(dict.fromkeys(default_origins + configured_origins))

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --------------------------------------------------
# MQTT and collection state
# --------------------------------------------------

mqtt_state = {
    "state": "starting",
    "error": None,
    "messages_received": 0,
    "last_message_at": None,
    "topic": None,
}

mqtt_lock = threading.Lock()
last_insert_lock = threading.Lock()

mqtt_started = False
mqtt_thread = None
mqtt_client = None

collection_enabled = True
last_insert_monotonic = 0.0


# --------------------------------------------------
# Incoming telemetry schema
# --------------------------------------------------

class TelemetryIn(BaseModel):
    device_id: str = "esp32"

    temperature_c: float | None = None
    humidity_pct: float | None = None

    accel_x_rms: float | None = None
    accel_y_rms: float | None = None
    accel_z_rms: float | None = None

    sound_rms: float | None = None
    acs712_reading: float | None = None
    current: float | None = None  # Alias used by the ESP32 firmware

    gyro_x: float | None = None
    gyro_y: float | None = None
    gyro_z: float | None = None

    vibration_magnitude: float | None = None
    vibration_x: float | None = None
    vibration_y: float | None = None
    vibration_z: float | None = None

    audio_value: float | None = None

    motor_rpm: float | None = None
    motor_load: float | None = None


# --------------------------------------------------
# Telemetry processing and ML prediction
# --------------------------------------------------

def process_payload(payload, source="mqtt"):
    global last_insert_monotonic

    # Prevent saving more than approximately one record per second.
    now = time.monotonic()

    with last_insert_lock:
        if now - last_insert_monotonic < 0.90:
            return {
                "saved": False,
                "reason": "rate_limited",
            }

        last_insert_monotonic = now

    # Persist telemetry first so ML errors do not lose sensor readings.
    row_id = insert_telemetry(payload)

    prediction_saved = False
    prediction_result = None
    prediction_error = None

    try:
        pred = predict(payload)
        prediction_result = pred

        # Store a new prediction for this telemetry row whenever the model
        # produced a valid anomaly flag. A skipped prediction includes a note.
        if pred.get("anomaly_flag") is not None:
            save_prediction(
                row_id,
                pred["anomaly_flag"],
                pred.get("anomaly_score"),
                pred.get("anomaly_probability"),
                pred.get("failure_prediction"),
                pred.get("failure_probability"),
                pred.get("model_version"),
            )
            prediction_saved = True
        elif pred.get("prediction_note"):
            prediction_error = pred["prediction_note"]

        with mqtt_lock:
            mqtt_state["error"] = prediction_error

    except Exception as exc:
        prediction_error = f"ML prediction error: {exc}"
        with mqtt_lock:
            mqtt_state["error"] = prediction_error

    return {
        "saved": True,
        "id": row_id,
        "prediction_saved": prediction_saved,
        "prediction": prediction_result,
        "prediction_error": prediction_error,
    }


# --------------------------------------------------
# MQTT worker
# --------------------------------------------------

def mqtt_worker():
    global mqtt_started, mqtt_client

    try:
        import paho.mqtt.client as mqtt

        host = os.getenv("MQTT_HOST", "broker.hivemq.com")
        port = int(os.getenv("MQTT_PORT", "1883"))
        topic = os.getenv("MQTT_TOPIC", "predictx/telemetry")
        client_id = os.getenv(
            "MQTT_CLIENT_ID",
            "predictx-api-subscriber",
        )

        with mqtt_lock:
            mqtt_state.update(
                state="connecting",
                error=None,
                topic=topic,
            )

        client = mqtt.Client(
            mqtt.CallbackAPIVersion.VERSION2,
            client_id=client_id,
        )

        mqtt_client = client

        def on_connect(
            client,
            userdata,
            flags,
            reason_code,
            properties,
        ):
            if reason_code == 0:
                if collection_enabled:
                    client.subscribe(topic, qos=0)

                    with mqtt_lock:
                        mqtt_state.update(
                            state="connected_subscribed",
                            error=None,
                        )
                else:
                    with mqtt_lock:
                        mqtt_state.update(
                            state="connected_paused",
                            error=None,
                        )
            else:
                with mqtt_lock:
                    mqtt_state.update(
                        state="connection_rejected",
                        error=str(reason_code),
                    )

        def on_disconnect(
            client,
            userdata,
            disconnect_flags,
            reason_code,
            properties,
        ):
            with mqtt_lock:
                mqtt_state["state"] = "disconnected_reconnecting"

                if str(reason_code) not in ("Success", "0"):
                    mqtt_state["error"] = str(reason_code)

        def on_message(client, userdata, msg):
            if not collection_enabled:
                return

            try:
                payload = json.loads(
                    msg.payload.decode("utf-8")
                )

                if not isinstance(payload, dict):
                    raise ValueError(
                        "JSON payload must be an object"
                    )

                process_payload(payload, "mqtt")

                with mqtt_lock:
                    mqtt_state["messages_received"] += 1
                    mqtt_state["last_message_at"] = (
                        datetime.now(timezone.utc).isoformat()
                    )
                    mqtt_state["error"] = None

            except Exception as exc:
                with mqtt_lock:
                    mqtt_state["error"] = (
                        f"Message parse/store error: {exc}"
                    )

        client.on_connect = on_connect
        client.on_disconnect = on_disconnect
        client.on_message = on_message

        client.connect(host, port, keepalive=60)
        mqtt_started = True
        client.loop_forever()

    except Exception as exc:
        with mqtt_lock:
            mqtt_state.update(
                state="connection_error",
                error=str(exc),
            )


# --------------------------------------------------
# Application startup
# --------------------------------------------------

@app.on_event("startup")
def startup():
    global mqtt_thread, mqtt_started

    try:
        init_db()

    except Exception as exc:
        with mqtt_lock:
            mqtt_state.update(
                state="database_error",
                error=f"MySQL initialization failed: {exc}",
            )

    # Start MQTT listener in the background.
    mqtt_thread = threading.Thread(
        target=mqtt_worker,
        daemon=True,
        name="predictx-mqtt",
    )
    mqtt_thread.start()
    mqtt_started = True


# --------------------------------------------------
# Collection controls
# --------------------------------------------------

@app.get("/api/collection")
def collection_status():
    with mqtt_lock:
        return {
            "enabled": collection_enabled,
            "mqtt_state": mqtt_state.get("state"),
            "topic": mqtt_state.get("topic"),
        }


@app.post("/api/collection/{action}")
def collection_control(action: str):
    global collection_enabled

    if action not in ("start", "stop"):
        raise HTTPException(
            status_code=404,
            detail="Action must be start or stop",
        )

    with mqtt_lock:
        collection_enabled = action == "start"

        client = mqtt_client
        topic = (
            mqtt_state.get("topic")
            or os.getenv("MQTT_TOPIC", "predictx/telemetry")
        )

        if (
            client is not None
            and mqtt_state.get("state")
            in ("connected_subscribed", "connected_paused")
        ):
            try:
                if collection_enabled:
                    client.subscribe(topic, qos=0)

                    mqtt_state.update(
                        state="connected_subscribed",
                        error=None,
                    )
                else:
                    client.unsubscribe(topic)

                    mqtt_state.update(
                        state="connected_paused",
                        error=None,
                    )

            except Exception as exc:
                mqtt_state["error"] = (
                    f"Could not {action} MQTT collection: {exc}"
                )
                raise HTTPException(
                    status_code=503,
                    detail=mqtt_state["error"],
                )

        return {
            "enabled": collection_enabled,
            "mqtt_state": mqtt_state.get("state"),
            "message": (
                "MQTT collection started"
                if collection_enabled
                else "MQTT collection stopped; "
                     "backend unsubscribed from telemetry"
            ),
        }


# --------------------------------------------------
# Health endpoint
# --------------------------------------------------

@app.get("/api/health")
def health():
    try:
        stats = count_telemetry()
        db_status = "connected"

    except Exception as exc:
        stats = {
            "count": 0,
            "latest": None,
        }
        db_status = f"error: {exc}"

    with mqtt_lock:
        mqtt_copy = dict(mqtt_state)

    return {
        "api": "ok",
        "database": db_status,
        "mqtt": mqtt_copy,
        "collection_enabled": collection_enabled,
        "telemetry": stats,
        "models": model_status(),
    }


# --------------------------------------------------
# Telemetry endpoints
# --------------------------------------------------

@app.get("/api/telemetry")
def telemetry(
    limit: int = Query(200, ge=1, le=5000),
    since_id: int | None = None,
):
    try:
        return {
            "items": fetch_telemetry(limit, since_id)
        }

    except Exception as exc:
        raise HTTPException(
            status_code=503,
            detail=f"Database unavailable: {exc}",
        )


@app.get("/api/telemetry/count")
def telemetry_count():
    try:
        return count_telemetry()

    except Exception as exc:
        raise HTTPException(
            status_code=503,
            detail=f"Database unavailable: {exc}",
        )


@app.post("/api/telemetry")
def manual_telemetry(data: dict):
    # Useful for integration tests.
    # Normal ESP32 telemetry arrives through MQTT.
    try:
        return process_payload(data, "rest")

    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=str(exc),
        )


# --------------------------------------------------
# Prediction endpoints
# --------------------------------------------------

@app.get("/api/predictions")
def predictions(
    limit: int = Query(100, ge=1, le=1000),
):
    try:
        return {
            "items": fetch_predictions(limit)
        }

    except Exception as exc:
        raise HTTPException(
            status_code=503,
            detail=f"Database unavailable: {exc}",
        )


# --------------------------------------------------
# ML model endpoints
# --------------------------------------------------

@app.post("/api/models/train")
def train():
    try:
        return train_models()

    except Exception as exc:
        raise HTTPException(
            status_code=400,
            detail=str(exc),
        )


@app.get("/api/models/status")
def models():
    return model_status()


# --------------------------------------------------
# Dataset information
# --------------------------------------------------

@app.get("/api/dataset")
def dataset_info():
    import pandas as pd
    from ml_service import DATASET

    df = pd.read_csv(DATASET)

    target = (
        "is_anomaly"
        if "is_anomaly" in df
        else "failure"
        if "failure" in df
        else None
    )

    labels = (
        {
            str(int(key)): int(value)
            for key, value in (
                df[target].value_counts().sort_index().items()
            )
        }
        if target
        else {}
    )

    return {
        "name": DATASET.name,
        "rows": len(df),
        "columns": list(df.columns),
        "target": target,
        "class_counts": labels,
        "note": (
            "Model training uses the uploaded preprocessed "
            "sensor dataset and its is_anomaly labels."
        ),
    }
