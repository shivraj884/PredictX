import os
import json
from contextlib import contextmanager
from datetime import datetime, timezone
import mysql.connector
from mysql.connector import pooling
from dotenv import load_dotenv

load_dotenv()

_pool = None

def get_pool():
    global _pool
    if _pool is None:
        _pool = pooling.MySQLConnectionPool(
            pool_name="predictx_pool",
            pool_size=5,
            host=os.getenv("MYSQL_HOST", "127.0.0.1"),
            port=int(os.getenv("MYSQL_PORT", "3306")),
            user=os.getenv("MYSQL_USER", "predictx"),
            password=os.getenv("MYSQL_PASSWORD", "change_this_password"),
            database=os.getenv("MYSQL_DATABASE", "predictx"),
            autocommit=False,
        )
    return _pool

@contextmanager
def connection():
    conn = get_pool().get_connection()
    try:
        yield conn
    finally:
        conn.close()

def init_db():
    # Create tables inside configured database; database itself must already exist.
    statements = [
        """CREATE TABLE IF NOT EXISTS telemetry (
          id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
          received_at TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
          device_id VARCHAR(80) NOT NULL DEFAULT 'esp32',
          temperature_c DOUBLE NULL, humidity_pct DOUBLE NULL,
          vibration_x DOUBLE NULL, vibration_y DOUBLE NULL, vibration_z DOUBLE NULL,
          audio_value DOUBLE NULL, acs712_reading DOUBLE NULL,
          gyro_x DOUBLE NULL, gyro_y DOUBLE NULL, gyro_z DOUBLE NULL, vibration_magnitude DOUBLE NULL,
          motor_rpm DOUBLE NULL, motor_load DOUBLE NULL, raw_json JSON NOT NULL,
          INDEX idx_telemetry_received_at (received_at),
          INDEX idx_telemetry_device_time (device_id, received_at)
        )""",
        """CREATE TABLE IF NOT EXISTS model_predictions (
          id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
          telemetry_id BIGINT UNSIGNED NOT NULL,
          predicted_at TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
          anomaly_flag TINYINT(1) NOT NULL, anomaly_score DOUBLE NULL, anomaly_probability DOUBLE NULL,
          failure_prediction TINYINT(1) NULL, failure_probability DOUBLE NULL,
          model_version VARCHAR(80) NULL,
          CONSTRAINT fk_prediction_telemetry FOREIGN KEY (telemetry_id) REFERENCES telemetry(id) ON DELETE CASCADE,
          INDEX idx_prediction_time (predicted_at)
        )"""
    ]
    with connection() as conn:
        cur = conn.cursor()
        for stmt in statements:
            cur.execute(stmt)
        # Safe migrations for databases created by earlier PredictX versions.
        cur.execute("SHOW COLUMNS FROM telemetry")
        existing = {row[0] for row in cur.fetchall()}
        additions = {
            'acs712_reading': 'DOUBLE NULL', 'gyro_x': 'DOUBLE NULL',
            'gyro_y': 'DOUBLE NULL', 'gyro_z': 'DOUBLE NULL',
            'vibration_magnitude': 'DOUBLE NULL'
        }
        for column, definition in additions.items():
            if column not in existing:
                cur.execute(f"ALTER TABLE telemetry ADD COLUMN {column} {definition}")
        cur.execute("SHOW COLUMNS FROM model_predictions")
        prediction_columns = {row[0] for row in cur.fetchall()}
        if 'anomaly_probability' not in prediction_columns:
            cur.execute("ALTER TABLE model_predictions ADD COLUMN anomaly_probability DOUBLE NULL")
        conn.commit()
        cur.close()

def insert_telemetry(payload):
    def first(*keys):
        for key in keys:
            val = payload.get(key)
            if val is not None:
                try:
                    return float(val)
                except (TypeError, ValueError):
                    return None
        return None
    device_id = str(payload.get("device_id", payload.get("device", "esp32")))[:80]
    values = (
        device_id,
        first("temperature_c", "dht22_temperature", "temp", "temperature"),
        first("humidity_pct", "dht22_humidity", "humidity", "humidity_percent"),
        first("accel_x_rms", "mpu6050_accel_x", "vibration_x", "accel_x", "acceleration_x"),
        first("accel_y_rms", "mpu6050_accel_y", "vibration_y", "accel_y", "acceleration_y"),
        first("accel_z_rms", "mpu6050_accel_z", "vibration_z", "accel_z", "acceleration_z"),
        first("sound_rms", "soundsensor_reading", "audio_rms", "audio_value", "audio", "sound"),
        first("acs712_reading", "acs712", "current_reading", "current_sensor", "current", "current_amps"),
        first("gyro_x", "mpu6050_gyro_x"),
        first("gyro_y", "mpu6050_gyro_y"),
        first("gyro_z", "mpu6050_gyro_z"),
        first("vibration_magnitude", "mpu6050_vibration_magnitude"),
        first("motor_rpm", "rpm"),
        first("motor_load", "load"),
        json.dumps(payload, allow_nan=False),
    )
    with connection() as conn:
        cur = conn.cursor()
        cur.execute("""INSERT INTO telemetry
          (device_id, temperature_c, humidity_pct, vibration_x, vibration_y, vibration_z,
           audio_value, acs712_reading, gyro_x, gyro_y, gyro_z, vibration_magnitude, motor_rpm, motor_load, raw_json)
          VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""", values)
        row_id = cur.lastrowid
        conn.commit()
        cur.close()
        return row_id

def fetch_telemetry(limit=200, since_id=None):
    limit = max(1, min(int(limit), 5000))
    with connection() as conn:
        cur = conn.cursor(dictionary=True)
        if since_id is not None:
            cur.execute(f"""SELECT id, received_at, device_id, temperature_c, humidity_pct,
                vibration_x, vibration_y, vibration_z, audio_value, acs712_reading, gyro_x, gyro_y, gyro_z, vibration_magnitude, motor_rpm, motor_load
                FROM telemetry WHERE id > %s ORDER BY id DESC LIMIT {limit}""", (int(since_id),))
        else:
            cur.execute(f"""SELECT id, received_at, device_id, temperature_c, humidity_pct,
                vibration_x, vibration_y, vibration_z, audio_value, acs712_reading, gyro_x, gyro_y, gyro_z, vibration_magnitude, motor_rpm, motor_load
                FROM telemetry ORDER BY id DESC LIMIT {limit}""")
        rows = cur.fetchall()
        cur.close()
    for row in rows:
        if row.get("received_at"):
            row["received_at"] = row["received_at"].isoformat()
    return list(reversed(rows))

def count_telemetry():
    with connection() as conn:
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*), MAX(received_at) FROM telemetry")
        count, latest = cur.fetchone()
        cur.close()
    return {"count": int(count or 0), "latest": latest.isoformat() if latest else None}

def save_prediction(telemetry_id, anomaly_flag, anomaly_score, anomaly_probability, failure_prediction, failure_probability, model_version):
    with connection() as conn:
        cur = conn.cursor()
        cur.execute("""INSERT INTO model_predictions
          (telemetry_id, anomaly_flag, anomaly_score, anomaly_probability, failure_prediction, failure_probability, model_version)
          VALUES (%s,%s,%s,%s,%s,%s,%s)""",
          (telemetry_id, int(anomaly_flag), anomaly_score, anomaly_probability, failure_prediction, failure_probability, model_version))
        conn.commit()
        cur.close()

def fetch_predictions(limit=100):
    limit = max(1, min(int(limit), 1000))
    with connection() as conn:
        cur = conn.cursor(dictionary=True)
        cur.execute(f"""SELECT p.id, p.telemetry_id, p.predicted_at, p.anomaly_flag, p.anomaly_score, p.anomaly_probability,
             p.failure_prediction, p.failure_probability, p.model_version, t.received_at,
             t.temperature_c, t.humidity_pct, t.vibration_x, t.vibration_y, t.vibration_z, t.audio_value, t.acs712_reading, t.gyro_x, t.gyro_y, t.gyro_z, t.vibration_magnitude
             FROM model_predictions p JOIN telemetry t ON t.id=p.telemetry_id
             ORDER BY p.id DESC LIMIT {limit}""")
        rows = cur.fetchall()
        cur.close()
    for row in rows:
        if row.get("predicted_at"): row["predicted_at"] = row["predicted_at"].isoformat()
        if row.get("received_at"): row["received_at"] = row["received_at"].isoformat()
    return list(reversed(rows))
