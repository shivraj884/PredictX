/* PredictX ESP32 DevKit + MPU6050 + INMP441
   Arduino IDE libraries: Adafruit MPU6050, Adafruit Unified Sensor, PubSubClient.
   INMP441 uses ESP32 I2S driver. MQTT topic must match backend/.env.
   Wiring defaults: MPU6050 SDA=21 SCL=22; INMP441 SCK/BCLK=26, WS/LRCL=25, SD/DOUT=33.
   Sound RMS is raw signed 24-bit microphone PCM scaled to a float, NOT dB SPL.
*/
#include <WiFi.h>
#include <Wire.h>
#include <math.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <PubSubClient.h>
#include "driver/i2s.h"

const char* WIFI_SSID = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* MQTT_HOST = "broker.hivemq.com";
const int MQTT_PORT = 1883;
const char* MQTT_TOPIC = "predictx/telemetry";
const char* DEVICE_ID = "esp32-machine-01";

#define I2S_PORT I2S_NUM_0
#define I2S_BCLK 26
#define I2S_WS   25
#define I2S_SD   33
#define SAMPLE_RATE 16000
#define RMS_SAMPLES 1024

Adafruit_MPU6050 mpu;
WiFiClient wifiClient;
PubSubClient mqtt(wifiClient);
unsigned long lastPublish = 0;

void setupI2S() {
  i2s_config_t cfg = {};
  cfg.mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX);
  cfg.sample_rate = SAMPLE_RATE;
  cfg.bits_per_sample = I2S_BITS_PER_SAMPLE_32BIT;
  cfg.channel_format = I2S_CHANNEL_FMT_ONLY_LEFT; // INMP441 L/R tied LOW; use ONLY_RIGHT if tied HIGH
  cfg.communication_format = I2S_COMM_FORMAT_STAND_I2S;
  cfg.intr_alloc_flags = ESP_INTR_FLAG_LEVEL1;
  cfg.dma_buf_count = 4;
  cfg.dma_buf_len = 256;
  cfg.use_apll = false;
  cfg.tx_desc_auto_clear = false;
  cfg.fixed_mclk = 0;
  i2s_pin_config_t pins = {};
  pins.bck_io_num = I2S_BCLK;
  pins.ws_io_num = I2S_WS;
  pins.data_out_num = I2S_PIN_NO_CHANGE;
  pins.data_in_num = I2S_SD;
  i2s_driver_install(I2S_PORT, &cfg, 0, nullptr);
  i2s_set_pin(I2S_PORT, &pins);
  i2s_zero_dma_buffer(I2S_PORT);
}

float readSoundRms() {
  int32_t samples[RMS_SAMPLES];
  size_t bytesRead = 0;
  i2s_read(I2S_PORT, samples, sizeof(samples), &bytesRead, portMAX_DELAY);
  int n = bytesRead / sizeof(int32_t);
  if (n <= 0) return 0.0f;
  // INMP441 samples are 24-bit data left-aligned in 32-bit words.
  double sumSq = 0.0;
  for (int i = 0; i < n; i++) {
    int32_t pcm24 = samples[i] >> 8;
    double v = (double)pcm24;
    sumSq += v * v;
  }
  return (float)sqrt(sumSq / n); // raw PCM RMS; calibrate for physical sound pressure
}

void connectWifi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) delay(500);
}
void reconnectMqtt() {
  while (!mqtt.connected()) {
    String clientId = String("PredictX-") + DEVICE_ID + "-" + String((uint32_t)ESP.getEfuseMac(), HEX);
    if (mqtt.connect(clientId.c_str())) break;
    delay(2000);
  }
}

void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);
  if (!mpu.begin()) {
    Serial.println("MPU6050 not found; check SDA/SCL and power.");
    while (true) delay(1000);
  }
  mpu.setAccelerometerRange(MPU6050_RANGE_4_G);
  mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);
  setupI2S();
  connectWifi();
  mqtt.setServer(MQTT_HOST, MQTT_PORT);
  mqtt.setBufferSize(512);
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) connectWifi();
  if (!mqtt.connected()) reconnectMqtt();
  mqtt.loop();
  if (millis() - lastPublish < 1000) return;
  lastPublish = millis();

  // RMS across a 1-second window of accelerometer samples, sampled at ~100 Hz.
  const int N = 100;
  double sx = 0, sy = 0, sz = 0;
  for (int i = 0; i < N; i++) {
    sensors_event_t a, g, t;
    mpu.getEvent(&a, &g, &t); // acceleration in m/s^2, includes gravity
    sx += (double)a.acceleration.x * a.acceleration.x;
    sy += (double)a.acceleration.y * a.acceleration.y;
    sz += (double)a.acceleration.z * a.acceleration.z;
    delay(10);
  }
  float axRms = sqrt(sx / N), ayRms = sqrt(sy / N), azRms = sqrt(sz / N);
  float soundRms = readSoundRms();
  char payload[384];
  snprintf(payload, sizeof(payload),
    "{\"device_id\":\"%s\",\"accel_x_rms\":%.5f,\"accel_y_rms\":%.5f,\"accel_z_rms\":%.5f,\"sound_rms\":%.3f}",
    DEVICE_ID, axRms, ayRms, azRms, soundRms);
  bool ok = mqtt.publish(MQTT_TOPIC, payload);
  Serial.printf("MQTT %s: %s\n", ok ? "sent" : "failed", payload);
}
