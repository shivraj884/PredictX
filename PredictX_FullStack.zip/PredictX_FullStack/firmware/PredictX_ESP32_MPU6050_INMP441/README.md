# PredictX ESP32 firmware (MPU6050 + INMP441)

## Libraries
Install via Arduino Library Manager: **Adafruit MPU6050**, **Adafruit Unified Sensor**, **PubSubClient**. ESP32 board support must be installed. The ESP32 Arduino core includes the I2S driver used here.

## Wiring
- MPU6050 VCC to 3V3, GND to GND, SDA to GPIO 21, SCL to GPIO 22.
- INMP441 VDD to 3V3, GND to GND, SCK/BCLK to GPIO 26, WS/LRCL to GPIO 25, SD/DOUT to GPIO 33, L/R to GND.
- Use 3.3 V logic; do not power these modules from 5 V unless the breakout explicitly supports it.

Set `WIFI_SSID` and `WIFI_PASSWORD`, select your ESP32 DevKit board, then upload. The firmware publishes once per second to `predictx/telemetry` on `broker.hivemq.com:1883`. Use a unique topic for non-demo/public deployments.

The MPU6050 RMS values are computed in m/s² and include gravity/DC offset; for vibration-only RMS, mount the sensor firmly and remove each axis's mean before calculating RMS. The current example is a simple baseline. `sound_rms` is raw INMP441 PCM RMS, not calibrated dB SPL. This firmware does not publish temperature/humidity because no environmental sensor was specified; add a DHT22/BME280 if those fields are needed.
