import React, { useEffect, useMemo, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { Activity, AlertTriangle, CheckCircle2, CircleGauge, Cpu, Database, Download, Gauge, RefreshCw, Server, Settings2, Thermometer, Waves, Wifi, Zap } from 'lucide-react'
import { Area, AreaChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import './styles.css'

const API = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000'
const num = (v, d=1) => v == null || Number.isNaN(Number(v)) ? '—' : Number(v).toFixed(d)
const when = v => v ? new Date(v).toLocaleTimeString() : 'Waiting for data'

function App() {
  const [health, setHealth] = useState(null)
  const [rows, setRows] = useState([])
  const [predictions, setPredictions] = useState([])
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState('')
  const [page, setPage] = useState('Overview')
  const [collectionEnabled, setCollectionEnabled] = useState(true)
  const [refreshing, setRefreshing] = useState(false)

  async function refresh() {
    try {
      const [h, t, p] = await Promise.all([
        fetch(`${API}/api/health`), fetch(`${API}/api/telemetry?limit=120`), fetch(`${API}/api/predictions?limit=120`)
      ])
      if (!h.ok || !t.ok || !p.ok) throw new Error('API request failed. Is the backend running?')
      const healthData = await h.json()
      setHealth(healthData); setCollectionEnabled(healthData.collection_enabled ?? true)
      setRows((await t.json()).items || []); setPredictions((await p.json()).items || [])
    } catch (e) { setNotice(e.message) }
  }
  async function fetchData() {
    setRefreshing(true); setNotice('')
    try { await refresh() } finally { setRefreshing(false) }
  }
  async function toggleCollection() {
    const action = collectionEnabled ? 'stop' : 'start'
    setNotice('')
    try {
      const r = await fetch(`${API}/api/collection/${action}`, { method: 'POST' })
      const data = await r.json()
      if (!r.ok) throw new Error(data.detail || 'Could not change data collection')
      setCollectionEnabled(data.enabled)
      setNotice(data.message)
      await refresh()
    } catch (e) { setNotice(e.message) }
  }
  useEffect(() => { /* Deliberately no polling: data is fetched only on button click. */ }, [])
  const latest = rows.at(-1) || {}
  const anomalyCount = predictions.filter(p => p.anomaly_flag === 1).length
  const failureProb = latest.id ? predictions.filter(p => p.telemetry_id === latest.id).at(-1)?.failure_probability : null
  const chartRows = useMemo(() => rows.map(r => ({ ...r, time: when(r.received_at) })), [rows])
  async function train() {
    setBusy(true); setNotice('')
    try {
      const r = await fetch(`${API}/api/models/train`, { method: 'POST' })
      const data = await r.json()
      if (!r.ok) throw new Error(data.detail || 'Training failed')
      setNotice(`Models trained on ${data.rows} dataset rows. Classifier: ${data.classifier_model}. ${data.note || ''}`)
      await refresh()
    } catch (e) { setNotice(e.message) } finally { setBusy(false) }
  }
  const downloadCsv = () => {
    const cols = ['id','received_at','device_id','temperature_c','humidity_pct','vibration_x','vibration_y','vibration_z','audio_value','acs712_reading','gyro_x','gyro_y','gyro_z','vibration_magnitude','motor_rpm','motor_load']
    const csv = [cols.join(','), ...rows.map(r => cols.map(c => JSON.stringify(r[c] ?? '')).join(','))].join('\n')
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], {type:'text/csv'})); a.download = 'predictx_telemetry.csv'; a.click(); URL.revokeObjectURL(a.href)
  }
  const mqtt = health?.mqtt?.state || 'checking'
  const db = health?.database || 'checking'
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-icon"><Activity size={23}/></div><div><strong>Predict<span>X</span></strong><small>INDUSTRIAL INTELLIGENCE</small></div></div>
      <div className="workspace"><span className="online-dot"/> LIVE WORKSPACE <span className="chevron">⌄</span></div>
      <div className="nav-label">MONITORING</div>
      {['Overview','Live telemetry','Maintenance AI','Data records'].map((p,i)=><button key={p} className={`nav-item ${page===p?'active':''}`} onClick={()=>setPage(p)}>{[<CircleGauge size={18}/>,<Waves size={18}/>,<Zap size={18}/>,<Database size={18}/>][i]}{p}</button>)}
      <div className="side-bottom"><div className="side-health"><div className="health-title"><span className="online-dot"/> System status</div><div className="health-row"><span>MQTT broker</span><b className={mqtt==='connected_subscribed'?'good':'muted'}>{mqtt==='connected_subscribed'?'Connected':mqtt}</b></div><div className="health-row"><span>MySQL database</span><b className={db==='connected'?'good':'muted'}>{db==='connected'?'Connected':db}</b></div><div className="health-row"><span>Latest packet</span><b>{when(health?.mqtt?.last_message_at)}</b></div></div><div className="profile"><div className="avatar">PX</div><div><b>PredictX Monitor</b><small>Local deployment</small></div><Settings2 size={17}/></div></div>
    </aside>
    <main className="main">
      <header className="topbar"><div><div className="eyebrow">PREDICTIVE MAINTENANCE / <span>{page.toUpperCase()}</span></div><h1>{page==='Overview'?'Machine health overview':page==='Live telemetry'?'Live sensor telemetry':page==='Maintenance AI'?'Maintenance intelligence':'Telemetry data records'}</h1><p>Monitor equipment signals, detect anomalies, and turn machine data into action.</p></div><div className="top-actions"><div className="live-pill"><span className="pulse"/> {collectionEnabled ? 'COLLECTION ON' : 'COLLECTION PAUSED'}</div><button className="export-button" onClick={fetchData} disabled={refreshing}><RefreshCw size={16}/> {refreshing ? 'Fetching…' : 'Fetch data'}</button><button className="secondary-button" onClick={toggleCollection}>{collectionEnabled ? 'Stop backend collection' : 'Start backend collection'}</button><button className="export-button" onClick={downloadCsv}><Download size={16}/> Export CSV</button></div></header>
      {notice && <div className="notice"><span>{notice}</span><button onClick={()=>setNotice('')}>×</button></div>}
      {health?.database?.startsWith('error') && <div className="warning"><AlertTriangle size={18}/><span><b>Database connection issue.</b> Check backend/.env and MySQL service. {health.database}</span></div>}
      {page==='Overview' && <>
        <div className="section-head"><div><h2>Operational snapshot</h2><span>Last known sensor readings</span></div><span className="updated"><span className="online-dot"/> Manual fetch only</span></div>
        <div className="metric-grid">
          <Metric icon={<Thermometer/>} label="Temperature" value={num(latest.temperature_c)} unit="°C" tone="orange" foot="Thermal sensor"/>
          <Metric icon={<Waves/>} label="Humidity" value={num(latest.humidity_pct)} unit="%" tone="blue" foot="Environment"/>
          <Metric icon={<Activity/>} label="Accel X RMS" value={num(latest.vibration_x,3)} unit="m/s²" tone="purple" foot="MPU6050 X axis"/>
          <Metric icon={<Activity/>} label="Accel Y RMS" value={num(latest.vibration_y,3)} unit="m/s²" tone="blue" foot="MPU6050 Y axis"/>
          <Metric icon={<Activity/>} label="Accel Z RMS" value={num(latest.vibration_z,3)} unit="m/s²" tone="orange" foot="MPU6050 Z axis"/>
          <Metric icon={<Zap/>} label="Sound RMS" value={num(latest.audio_value,0)} unit="PCM" tone="green" foot="INMP441 · uncalibrated"/>
          <Metric icon={<Zap/>} label="ACS712 reading" value={num(latest.acs712_reading,1)} unit="ADC" tone="green" foot="Current sensor · calibrate to A"/>
        </div>
        <div className="section-head chart-heading"><div><h2>Sensor performance</h2><span>Recent readings from MQTT telemetry</span></div><span className="range-tag">LAST {rows.length} RECORDS</span></div>
        <div className="charts-grid">
          <div className="panel chart-panel"><div className="panel-title"><div><b>Temperature</b><small>Degrees Celsius</small></div><span className="chart-value">{num(latest.temperature_c)}°</span></div><div className="chart"><ResponsiveContainer width="100%" height="100%"><AreaChart data={chartRows}><defs><linearGradient id="tempFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#f59e0b" stopOpacity={.24}/><stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/></linearGradient></defs><CartesianGrid strokeDasharray="3 4" stroke="#263146"/><XAxis dataKey="time" hide/><YAxis stroke="#728099" tickLine={false} axisLine={false} width={36}/><Tooltip contentStyle={{background:'#111a2b',border:'1px solid #2a3851',borderRadius:10}}/><Area type="monotone" dataKey="temperature_c" stroke="#f5a524" fill="url(#tempFill)" strokeWidth={2} dot={false} connectNulls/></AreaChart></ResponsiveContainer></div></div>
          <div className="panel chart-panel"><div className="panel-title"><div><b>Vibration signature</b><small>Acceleration by axis</small></div><span className="legend"><i/> X-axis</span></div><div className="chart"><ResponsiveContainer width="100%" height="100%"><LineChart data={chartRows}><CartesianGrid strokeDasharray="3 4" stroke="#263146"/><XAxis dataKey="time" hide/><YAxis stroke="#728099" tickLine={false} axisLine={false} width={36}/><Tooltip contentStyle={{background:'#111a2b',border:'1px solid #2a3851',borderRadius:10}}/><Line type="monotone" dataKey="vibration_x" stroke="#a78bfa" strokeWidth={2} dot={false} connectNulls/><Line type="monotone" dataKey="vibration_y" stroke="#4fd1c5" strokeWidth={2} dot={false} connectNulls/><Line type="monotone" dataKey="vibration_z" stroke="#60a5fa" strokeWidth={2} dot={false} connectNulls/></LineChart></ResponsiveContainer></div></div>
          <div className="panel chart-panel"><div className="panel-title"><div><b>ACS712 current sensor</b><small>Raw ADC/sensor reading · not amperes until calibrated</small></div><span className="chart-value">{num(latest.acs712_reading,1)}</span></div><div className="chart"><ResponsiveContainer width="100%" height="100%"><LineChart data={chartRows}><CartesianGrid strokeDasharray="3 4" stroke="#263146"/><XAxis dataKey="time" hide/><YAxis stroke="#728099" tickLine={false} axisLine={false} width={42}/><Tooltip contentStyle={{background:'#111a2b',border:'1px solid #2a3851',borderRadius:10}}/><Line type="monotone" dataKey="acs712_reading" name="ACS712 reading" stroke="#4fd1c5" strokeWidth={2} dot={false} connectNulls/></LineChart></ResponsiveContainer></div></div>
        </div>
        <div className="bottom-grid"><div className="panel"><div className="panel-title"><div><b>Maintenance AI status</b><small>Model readiness and alerts</small></div><Cpu size={19} className="subtle"/></div><div className="ai-status"><div className="ai-icon"><Zap size={22}/></div><div className="ai-copy"><b>Anomaly detection</b><span>Isolation Forest · {health?.models?.anomaly_ready?'Model ready':'Model not trained'}</span></div><span className={`status-tag ${health?.models?.anomaly_ready?'tag-good':'tag-warn'}`}>{health?.models?.anomaly_ready?'ACTIVE':'PENDING'}</span></div><div className="ai-status"><div className="ai-icon blue"><Gauge size={22}/></div><div className="ai-copy"><b>Sensor anomaly classifier</b><span>Random Forest · trained on is_anomaly labels</span></div><span className={`status-tag ${health?.models?.classifier_ready?'tag-good':'tag-warn'}`}>{health?.models?.classifier_ready?'ACTIVE':'PENDING'}</span></div><button className="secondary-button full" onClick={train} disabled={busy}>{busy?'Training models…':'Train / retrain models'}</button><p className="fine-print">Models train on preprocessed_sensor_data.csv (is_anomaly labels). Live accel RMS in m/s² is converted to g for model input. Important: INMP441 raw PCM RMS is not automatically equivalent to the dataset's soundsensor_reading; calibrate/normalize sound consistently before trusting live predictions.</p></div>
          <div className="panel"><div className="panel-title"><div><b>Recent activity</b><small>Latest database records</small></div><span className="range-tag">{rows.length} LOADED</span></div><div className="activity-list">{rows.slice(-5).reverse().map(r=><div className="activity-item" key={r.id}><div className="activity-dot"><CheckCircle2 size={16}/></div><div className="activity-text"><b>Telemetry record #{r.id}</b><span>{num(r.temperature_c)}°C · {num(r.humidity_pct)}% RH · Accel RMS X/Y/Z {num(r.vibration_x,3)}/{num(r.vibration_y,3)}/{num(r.vibration_z,3)} · Sound RMS {num(r.audio_value,0)}</span></div><time>{when(r.received_at)}</time></div>)}{!rows.length&&<div className="empty">Waiting for the first ESP32 message…</div>}</div></div></div>
      </>}
      {page==='Live telemetry' && <div className="panel table-panel"><div className="panel-title"><div><b>Incoming MQTT messages</b><small>Newest readings first · click Fetch data to update</small></div><Wifi size={18}/></div><TelemetryTable rows={[...rows].reverse()}/></div>}
      {page==='Maintenance AI' && <><div className="metric-grid"><Metric icon={<AlertTriangle/>} label="Anomalies in view" value={anomalyCount} unit="" tone="orange" foot="Last 120 predictions"/><Metric icon={<Cpu/>} label="Anomaly model" value={health?.models?.anomaly_ready?'Ready':'Pending'} unit="" tone="purple" foot="Isolation Forest"/><Metric icon={<Gauge/>} label="Anomaly classifier" value={health?.models?.classifier_ready?'Ready':'Not trained'} unit="" tone="blue" foot="Random Forest"/><Metric icon={<Database/>} label="Dataset rows" value={health?.models?.dataset_rows ?? "—"} unit="" tone="green" foot={health?.models?.dataset_kind || "Dataset rows"}/></div><div className="panel ai-page"><div className="panel-title"><div><b>Model controls</b><small>Train from backend/data/preprocessed_sensor_data.csv</small></div></div><p>Isolation Forest flags outliers, while Random Forest learns the dataset's is_anomaly labels. The uploaded dataset has 200 rows and 20 anomaly labels; use the displayed hold-out metrics as an initial check, not a guarantee of real-world accuracy.</p>{health?.models?.metrics && <div className="metric-grid model-metrics">{[['Accuracy',health.models.metrics.accuracy],['Precision',health.models.metrics.precision],['Recall',health.models.metrics.recall],['F1 score',health.models.metrics.f1]].map(([label,value])=><Metric key={label} icon={<Gauge/>} label={label} value={value==null?'—':`${(Number(value)*100).toFixed(1)}`} unit="%" tone="blue" foot="Hold-out evaluation"/>)}</div>}<button className="export-button" disabled={busy} onClick={train}>{busy?'Training…':'Train / retrain models'}</button><h3>Recent predictions</h3><TelemetryTable rows={[...predictions].reverse()} prediction/></div></>}
      {page==='Data records' && <div className="panel table-panel"><div className="panel-title"><div><b>Stored telemetry</b><small>MySQL persistence · newest records</small></div><button className="export-button" onClick={downloadCsv}><Download size={15}/> Export CSV</button></div><TelemetryTable rows={[...rows].reverse()}/></div>}
      <footer><span>PredictX <b>v1.1</b> · MQTT → REST API → MySQL → ML</span><span><Server size={14}/> Local monitoring stack</span><span>* Check MPU6050 units and calibration.</span></footer>
    </main>
  </div>
}
function Metric({icon,label,value,unit,tone,foot}) { return <div className="metric-card"><div className="metric-top"><span>{label}</span><span className={`metric-icon ${tone}`}>{icon}</span></div><div className="metric-number">{value}<small>{unit}</small></div><div className="metric-foot"><span className="tiny-dot"/> {foot}</div></div> }
function TelemetryTable({rows,prediction=false}) {
  if (!rows?.length) return <div className="empty">No records yet. Check MQTT and MySQL connection status.</div>
  return <div className="table-scroll"><table><thead><tr>{(prediction?['Record','Time','Temperature','Humidity','Accel X','ACS712','Anomaly','Anomaly probability']:['ID','Received at','Device','Temp °C','Humidity %','Accel X','Accel Y','Accel Z','Sound RMS','ACS712','Gyro X','Gyro Y','Gyro Z']).map(x=><th key={x}>{x}</th>)}</tr></thead><tbody>{rows.map((r,i)=><tr key={r.id||r.telemetry_id||i}>{prediction?<><td>#{r.telemetry_id}</td><td>{when(r.predicted_at)}</td><td>{num(r.temperature_c)}°</td><td>{num(r.humidity_pct)}%</td><td>{num(r.vibration_x)}</td><td>{num(r.acs712_reading)}</td><td><span className={`status-tag ${r.anomaly_flag?'tag-warn':'tag-good'}`}>{r.anomaly_flag?'Anomaly':'Normal'}</span></td><td>{r.anomaly_probability==null?'—':`${(r.anomaly_probability*100).toFixed(1)}%`}</td></>:<><td>#{r.id}</td><td>{r.received_at?new Date(r.received_at).toLocaleString():'—'}</td><td>{r.device_id}</td><td>{num(r.temperature_c)}</td><td>{num(r.humidity_pct)}</td><td>{num(r.vibration_x)}</td><td>{num(r.vibration_y)}</td><td>{num(r.vibration_z)}</td><td>{num(r.audio_value,0)}</td><td>{num(r.acs712_reading,1)}</td><td>{num(r.gyro_x,3)}</td><td>{num(r.gyro_y,3)}</td><td>{num(r.gyro_z,3)}</td></>}</tr>)}</tbody></table></div>
}
createRoot(document.getElementById('root')).render(<App/>)
