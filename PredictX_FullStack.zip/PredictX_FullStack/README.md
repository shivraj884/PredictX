# PredictX — sensor anomaly monitoring (ACS712 enabled)

This version uses the supplied `preprocessed_sensor_data.csv` dataset to train anomaly models and updates the React UI to show ACS712 readings. It retains the manual **Fetch data** button and backend MQTT collection start/stop controls.

## Dataset and model

Place `preprocessed_sensor_data.csv` at `backend/data/preprocessed_sensor_data.csv` (the supplied dataset is included). The dataset has 200 rows and these key fields: MPU6050 accelerometer X/Y/Z, gyro X/Y/Z, sound sensor reading, ACS712 reading, DHT22 temperature/humidity, vibration magnitude, and the binary target `is_anomaly` (180 normal / 20 anomaly rows).

Click **Train / retrain models** on the Maintenance AI page. The backend trains:
- Isolation Forest for unsupervised outlier detection.
- Random Forest classifier using the dataset's `is_anomaly` labels.
- Hold-out accuracy, precision, recall and F1 metrics are shown in the UI after training.

These scores are only an initial check on this small dataset. They do not guarantee accuracy on a physical machine. Training and live data must use comparable units, sensor placement, sampling windows and preprocessing. Live `accel_*_rms` values in m/s² are converted to g for model input. However, INMP441 raw PCM RMS is not automatically equivalent to the dataset’s `soundsensor_reading`; calibrate/normalize sound consistently before trusting live predictions. ACS712 values are shown as raw sensor/ADC readings, not amperes unless calibrated.

## Backend setup (Windows)

```bat
cd backend
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
copy .env.example .env
```

Edit `backend/.env` with your MySQL credentials. Create the MySQL database/user as appropriate for your setup; `schema.sql` creates the database and tables. On startup, the API also adds the new ACS712, gyroscope, vibration magnitude, and anomaly probability columns to an existing PredictX schema.

Run the API:

```bat
python -m uvicorn main:app --host 127.0.0.1 --port 8000
```

API docs: `http://127.0.0.1:8000/docs`

## Frontend setup (separate terminal)

```bat
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`. Click **Fetch data** to refresh the dashboard manually. **Stop backend collection** unsubscribes the backend from its MQTT topic; the ESP32 may still publish to the broker. Start collection again with the button when needed.

## MQTT fields

The backend accepts aliases for sensor fields, including:

- `accel_x_rms`, `accel_y_rms`, `accel_z_rms` (also `mpu6050_accel_x/y/z`)
- `gyro_x`, `gyro_y`, `gyro_z` (also `mpu6050_gyro_x/y/z`)
- `sound_rms` (also `soundsensor_reading` / `audio_value`)
- `acs712_reading`
- `temp` / `dht22_temperature`, `humidity` / `dht22_humidity`
- optional `vibration_magnitude`

Default broker/topic: `broker.hivemq.com:1883`, `predictx/telemetry`. Configure in `backend/.env`.

## Notes

- Existing MySQL rows are preserved by the migration.
- Dashboard fetch is manual; it does not continuously poll the API.
- Public MQTT topics are not private. Use a unique topic and authenticated broker for non-demo use.
